# ---------------- LIST OPERATIONS ----------------

print("   LIST OPERATIONS  ")

my_list = [50, 20, 40, 10, 30]

print("Original List:", my_list)

# append()
my_list.append(60)
print("After append(60):", my_list)

# insert()
my_list.insert(2, 25)
print("After insert(2, 25):", my_list)

# remove()
my_list.remove(20)
print("After remove(20):", my_list)

# pop()
my_list.pop()
print("After pop():", my_list)

# sort()
my_list.sort()
print("After sort():", my_list)


# ---------------- TUPLE OPERATIONS ----------------

print("   TUPLE OPERATIONS  ")

my_tuple = (10, 20, 30, 20, 40)

print("Original Tuple:", my_tuple)

# count()
print("Count of 20:", my_tuple.count(20))

# index()
print("Index of 30:", my_tuple.index(30))

# concatenation
new_tuple = my_tuple + (50, 60)
print("After concatenation:", new_tuple)

# repetition
print("After repetition:", my_tuple * 2)

# slicing
print("Tuple slicing:", my_tuple[1:4])


# ---------------- DICTIONARY OPERATIONS ----------------

print("  DICTIONARY OPERATIONS  ")

student = {
    "name": "Rahul",
    "age": 20,
    "course": "Computer Engineering",
    "marks": 85
}

print("Original Dictionary:", student)

# keys()
print("Keys:", student.keys())

# values()
print("Values:", student.values())

# items()
print("Items:", student.items())

# get()
print("Name:", student.get("name"))

# update()
student.update({"marks": 90})
print("After update:", student)

# pop()
student.pop("age")
print("After pop('age'):", student)



