import re

# Accept string from user
text = input("Enter a string: ")

# Check whether string contains only a-z, A-Z and 0-9
if re.fullmatch(r"[a-zA-Z0-9]+", text):
    print("Valid string")
else:
    print("Invalid string")


