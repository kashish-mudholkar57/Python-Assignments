# Matrix addition using Python lists

A = [
    [1, 2],
    [3, 4]
]

B = [
    [5, 6],
    [7, 8]
]

# Create result matrix
result = [
    [0, 0],
    [0, 0]
]

# Add corresponding elements
for i in range(2):
    for j in range(2):
        result[i][j] = A[i][j] + B[i][j]

print("Matrix A:")
for row in A:
    print(row)

print("Matrix A:")
for row in A:
    print(row)

print("Matrix B:")
for row in B:
    print(row)

print("Addition of matrices:")
for row in result:
    print(row)
# Matrix addition using NumPy

import numpy as np

A = np.array([
    [1, 2],
    [3, 4]
])

B = np.array([
    [5, 6],
    [7, 8]
])

result_2 = A + B

print("Matrix A:")
print(A)

print("Matrix B:")
print(B)

print("Addition of matrices:")
print(result_2)
