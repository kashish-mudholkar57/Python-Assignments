a= float(input(‘Enter length of 1st side: ‘))
b= float(input(‘Enter length of 2nd side: ‘))
c= float(input(‘Enter length of 3rd side: ‘))

def right_angle(a,b,c):
	largest= max(a,b,c)
	if largest==a:
	  if a * a == b * b + c * c:
		return True
	elif  largest == b:
	  if b * b == a * a + c * c :
		return True
	else:
	  if largest==c:
		if c * c == a * a + b * b :
		  return True
		return False
if right_triangle:
  print("The triangle is a right-angled triangle.") 
else: 
  print("The triangle is not a right-angled triangle.") 
